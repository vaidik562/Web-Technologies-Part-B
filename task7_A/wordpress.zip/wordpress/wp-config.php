<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'vh(/%=t~z3Ue]D^^78]Y<d&qTyb`;@1%PMqv])Di_s3_Q -xo52`if*f%+yK?NU7' );
define( 'SECURE_AUTH_KEY',  'bT8g:b$o<n>H^#(hE:Z1Zo#HucUkvvoF&Vw}@x*=il4eL7RG~1a?M!sv>e]Qw-^L' );
define( 'LOGGED_IN_KEY',    '_wSr>geq[/SMW%TSy>&G.?W*_mL:/cz}!Fn$.{PA{W9B^0*f;^GLDP<#V1r3$/uj' );
define( 'NONCE_KEY',        ',kQsYt]y)~D,x,Xu(?}K|Tj3|W<MpYnT/0o7m7 <eCPzUGVBD.FB5U{~*VXJ$vu ' );
define( 'AUTH_SALT',        'v^izT.sz;NuIQ>cKdp_f,4P5cMrfk]<:NcmmcD_Ig3urm(t#Eo6U0pQ{gnbjc9OE' );
define( 'SECURE_AUTH_SALT', '<?I2K;R=iSwaV-Yb#/+Z3F10P BjdMe}v3_kHa^Y1n{{-,U9C_4|R[e_2lhFPF%o' );
define( 'LOGGED_IN_SALT',   'NIScY55Gh!Na]X* ]s mmLqD_&P?1FwddBBh9y{4mdL,t:AkPbp[j]`iH*u/Y&uc' );
define( 'NONCE_SALT',       '=1jjN3IwfX#?0`dTp^5^Ix;me^GH#-!z nu<@2khHT[4/3xvgXYrgh8y$^6p7&gH' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
